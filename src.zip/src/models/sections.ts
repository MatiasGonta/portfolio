export enum Sections {
    HOME = 'home',
    PROJECTS = 'projects',
    ABOUT = 'about',
    CONTACT = 'contact'
}